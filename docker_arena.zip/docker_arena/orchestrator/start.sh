#!/bin/bash
echo "Starting Orchestrator..."
python -u main.py
